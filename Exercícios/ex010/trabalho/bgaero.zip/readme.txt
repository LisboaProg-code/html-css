﻿=== Black-Green Aero Cursor Set ===

By: The Sword of the Heart

Download: http://www.rw-designer.com/cursor-set/bgaero

Author's decription:

A recolor of the Microsoft Windows Aero (MS WinVista) style cursors, for Windows NT 5.0, 5.1, 5.2, and 6.0 (Win2k and above).
The pointer is much darker and the spinny wheel thing is green. I did this to match my custom-made wallpaper but they're pretty good so I'll upload them.

==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.